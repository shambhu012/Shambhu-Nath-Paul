<?php
ob_start();
?>
<?php use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
$error='';
$name_error='';
$email_error='';
$phone_error='';
$subject_error=''; $message_error='';
$name='';$email='';$phone=''; $subject=''; $message='';
$date = date('Y-m-d H:i:s');

function clean_text($string)
{
	$string=trim($string);
	$string=stripslashes($string);
$string=htmlspecialchars($string);
return $string;
}
if(isset($_POST["submit"])){if(empty($_POST["name"]))
{
	$name_error.='<p><label class="text-danger">Please Enter your Name</label></p>';
}
else{
	$name=clean_text($_POST["name"]);if(!preg_match("/^[a-zA-Z ]*$/",$name))
{
	$name_error.='<p><label class="text-danger">Only letters and white space allowed in the name field.</label></p>';
}
	}
if(empty($_POST["email"]))
{
	$email_error.='<p><label class="text-danger">Please Enter your Email</label></p>';
}
else{
	$email=clean_text($_POST["email"]);if(!filter_var($email,FILTER_VALIDATE_EMAIL))
{
	$email_error.='<p><label class="text-danger">Invalid email format</label></p>';
}
	}
if(empty($_POST["phone"]))
{
	$phone_error.='<p><label class="text-danger">Phone number is required</label></p>';
}
else{
	$phone=clean_text($_POST["phone"]);
}

if($name_error==''&&$email_error==''&&$phone_error=='')
{
$mail=new PHPMailer;
$mail->IsSMTP();
$mail->Host='smtp.gmail.com';
$mail->Port=587;
$mail->SMTPAuth=true;
$mail->Username='contactshambhu2017@gmail.com';
$mail->Password='btfkblygwbjiobus';
//$mail->SMTPSecure='tls';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
$mail->From=$_POST["email"];
$mail->FromName=$_POST["name"];
$mail->AddAddress('shambhupaul1200@gmail.com','Email');

//$mail->AddAddress('contactshambhu2017@gmail.com');

$mail->WordWrap=50;
$mail->IsHTML(true);
$mail->Subject='New Email Message';

$mail->Body= "<div style='margin-left:150px; padding:50px;width:600px;'>

<hr>
<table>
<tr>
<td>
<div style='float:left;'>
<h2>Contact Person Name</h2>
<p style='color:#1483bb; font-family: Allura,cursive,Arial, Helvetica, sans-serif; font-size:20px'>".$_POST['name']."</p>
</div>
</td>
</tr>
<hr>
<tr>
<td><div style='float:left;'>
<h2>EMAIL</h2>
<p style='color:#1483bb;font-family: Arial, Helvetica, sans-serif; font-size:20px'>".$_POST["email"]."</p></div></td>
</tr>
<hr>
<tr>
<td><div style='float:left;'>
<h2>PHONE NUMBER</h2>
<p style='color:#1483bb;font-family: Arial, Helvetica, sans-serif; font-size:20px'>".$_POST["phone"]."</p></div></td>
</tr>


</table>
</div>"; 

if($mail->Send()) 
	{
		$error='  <div class="alert alert-success alert-dismissible fade show" role="alert">
					
                  <b>Thank you for contacting with us</b>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                  </button>

                </div>';
                header('Location: index.php');
                ob_end_flush();
				die();
				}
				else
				{
					$error='<div class="alert alert-warning alert-dismissible fade show" role="alert">

					  <b>There is an Error in email sending</b>

					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">

					    <span aria-hidden="true">&times;</span>

					  </button>

					</div>';
					}
$name='';$email='';$phone=''; $subject=''; $message='';
}

}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Shambhu Portfolio</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

 
</head>

<body id="page-top">

  <!--/ Nav Star /-->
  <nav class="navbar navbar-b navbar-trans navbar-expand-md fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll" href="#page-top">MyPortfolio</a>
      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
        aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-collapse collapse justify-content-end" id="navbarDefault">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link js-scroll active" href="#home">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#service">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#work">Work</a>
          </li>
          <!--<li class="nav-item">
            <a class="nav-link js-scroll" href="#blog">Blog</a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link js-scroll" href="#contact">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!--/ Nav End /-->

  <!--/ Intro Skew Star /-->
  <div id="home" class="intro route bg-image" style="background-image: url(img/shambhunath.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">I am Shambhu Nath Paul</h1>
          <p class="intro-subtitle"><span class="text-slider-items">I am a PHP Web Developer, Web Designer.</span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div>
  <!--/ Intro Skew End /-->

  <section id="about" class="about-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="box-shadow-full">
            <div class="row">
              <div class="col-md-6">
                <div class="row">
                  <div class="col-sm-6 col-md-5">
                    <div class="about-img">
                      <img src="img/shambhupaul.jpg" class="img-fluid rounded b-shadow-a" alt="">
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-7">
                    <div class="about-info">
                      <p><span class="title-s">Name: </span> <span>Shambhu Nath Paul</span></p>
                      <p><span class="title-s">Profile: </span> <span>Web developer</span></p>
                      <p><span class="title-s">Email: </span> <span>contactshambhu2017@gmail.com</span></p>
                      <p><span class="title-s">Phone: </span> <span>8420566643</span></p>
                    </div>
                  </div>
                </div>
                <div class="skill-mf">
                  <p class="title-s">Skill</p>
                  <span>HTML</span> <span class="pull-right">85%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                  <span>CSS3</span> <span class="pull-right">75%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                  <span>PHP</span> <span class="pull-right">80%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="50" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                  <span>JAVASCRIPT</span> <span class="pull-right">80%</span>
                  <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="90" aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="about-me pt-4 pt-md-0">
                  <div class="title-box-2">
                    <h5 class="title-left">
                      About Me
                    </h5>
                  </div>
                  <p class="lead">
                    Hi, I am Shambhu. I created websites using php. I worked on Html, css, Boostrap, core PHP, javascipt, jQuery, Ajax. 
                  </p>
                  <p class="lead">
				  I also worked with frameworks like - Laravel, CI, Wordpress, Magento.
                  </p>
                  <p class="lead">
				  I can create both static and dynamic websites including e-commerce business websites.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--/ Section Services Star /-->
  <section id="service" class="services-mf route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Services
            </h3>
            <p class="subtitle-a">
              Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-monitor"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Web Design</h2>
              <p class="s-description text-center">
                Web design is the process of creating websites. It encompasses several different aspects, including webpage layout, content production, and graphic design. While the terms web design and web development are often used interchangeably, web design is technically a subset of the broader category of web development.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-code-working"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Web Development</h2>
              <p class="s-description text-center">
                7 of the most important web developer skills I have to build and developer a responsive, user-friendly, e-commerce website. HTML|CSS|PHP|JavaScript|
				WordPress|SEO|Responsive Design. As a web developer, I am working from home as a freelancer, as an intern.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-camera"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Logo & Pattern Design</h2>
              <p class="s-description text-center">
                I have just joined and started my working on various logo, pattern, brochure design and photography related websites like Behance, 99designs, Dribbble.
				I gathering various graphic, logo design ideas from here.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-android-phone-portrait"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Responsive Design</h2>
              <p class="s-description text-center">
                Web design is the process of creating websites. It encompasses several different aspects, including webpage layout, content production, and graphic design. While the terms web design and web development are often used interchangeably, web design is technically a subset of the broader category of web development.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-paintbrush"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Graphic Design</h2>
              <p class="s-description text-center">
                Web design is the process of creating websites. It encompasses several different aspects, including webpage layout, content production, and graphic design. While the terms web design and web development are often used interchangeably, web design is technically a subset of the broader category of web development.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="service-box">
            <div class="service-ico">
              <span class="ico-circle"><i class="ion-stats-bars"></i></span>
            </div>
            <div class="service-content">
              <h2 class="s-title">Digital Marketing</h2>
              <p class="s-description text-center">
                Web design is the process of creating websites. It encompasses several different aspects, including webpage layout, content production, and graphic design. While the terms web design and web development are often used interchangeably, web design is technically a subset of the broader category of web development.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ Section Services End /-->

  <div class="section-counter paralax-mf bg-image" style="background-image: url(img/counters-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-checkmark-round"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">21</p>
              <span class="counter-text">WORKS COMPLETED</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ios-calendar-outline"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">2</p>
              <span class="counter-text">YEARS OF EXPERIENCE</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ios-people"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">10</p>
              <span class="counter-text">TOTAL CLIENTS</span>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="counter-box pt-4 pt-md-0">
            <div class="counter-ico">
              <span class="ico-circle"><i class="ion-ribbon-a"></i></span>
            </div>
            <div class="counter-num">
              <p class="counter">4</p>
              <span class="counter-text">TOTAL BLOGS</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--/ Section Portfolio Star /-->
  <section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Portfolio
            </h3>
            <p class="subtitle-a">
              Some of my personal works as the work portfolio here
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/spacezin-PK-chetani.png" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/spacezin-PK-chetani.png" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="https://spacezin.in/">Spacezin Interior</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Home Decor & Office Designer</span><span class="w-date"></span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/asphenix.png" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/asphenix.png" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="http://asphenixsoftware.in/">Asphenixsoftware</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Software Solution</span><span class="w-date"></span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/socialinformation.png" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/socialinformation.png" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="https://www.socialinformation.site/">Socialinformation</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Digital Marketing Blog</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/shopping-cart-shopping.jpg" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/shopping-cart-shopping.jpg" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="https://shoppingonlineorder.blogspot.com/">Shopping Online</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Affiliate Marketing</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/emergency_plumber.png" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/emergency_plumber.png" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="https://www.emergencyplumber.london/">Emergency Plumber</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Plumber Service</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="img/glocaljunction.png" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="img/glocaljunction.png" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title"><a href="http://www.glocaljunction.com/">Glocal Junction</a></h2>
                    <div class="w-more">
                      <span class="w-ctegory">Food & Restaurant</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                      <span class="ion-ios-plus-outline"></span>
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        
      </div>
    </div>
  </section>
  <!--/ Section Portfolio End /-->

  <!--/ Section Testimonials Star /-->
  <div class="testimonials paralax-mf bg-image" style="background-image: url(img/overlay-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="testimonial-mf" class="owl-carousel owl-theme">
            <div class="testimonial-box">
              <div class="author-test">
                <img src="img/Spacezin-proprietor.jpg" alt="" class="rounded-circle b-shadow-a">
                <span class="author">Soumen Laha (Spacezin)</span>
              </div>
              <div class="content-test">
                <p class="description lead">
                  Exellent work. Ontime delivery. I am satishfied. He is a good fellow.
                </p>
                <span class="comit"><i class="fa fa-quote-right"></i></span>
              </div>
            </div>
            <div class="testimonial-box">
              <div class="author-test">
                <img src="img/Team-member-Sourav.jpg" alt="" class="rounded-circle b-shadow-a">
                <span class="author">Sourav Nandy</span>
              </div>
              <div class="content-test">
                <p class="description lead">
                  Good knowledge in web development. Ontime delivery is a good option for his career. Thanks.
                </p>
                <span class="comit"><i class="fa fa-quote-right"></i></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--/ Section Blog Star /-->
  <!--<section id="blog" class="blog-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              Blog
            </h3>
            <p class="subtitle-a">
              Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            </p>
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="img/post-1.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Travel</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="index.php">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/shambhupaul.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Shambhu Nath Paul</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="index.php"><img src="img/post-2.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="blog-single.html">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Morgan Freeman</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="img/post-3.jpg" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  <h6 class="category">Web Design</h6>
                </div>
              </div>
              <h3 class="card-title"><a href="blog-single.html">See more ideas about Travel</a></h3>
              <p class="card-description">
                Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Praesent sapien massa, convallis
                a pellentesque nec,
                egestas non nisi.
              </p>
            </div>
            <div class="card-footer">
              <div class="post-author">
                <a href="#">
                  <img src="img/testimonial-2.jpg" alt="" class="avatar rounded-circle">
                  <span class="author">Morgan Freeman</span>
                </a>
              </div>
              <div class="post-date">
                <span class="ion-ios-clock-outline"></span> 10 min
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>-->
  <!--/ Section Blog End /-->

  <!--/ Section Contact-Footer Star /-->
  <section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(img/overlay-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="contact-mf">
            <div id="contact" class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="title-box-2">
                    <h5 class="title-left">
                      Send Message me
                    </h5>
                  </div>
                  <div>
                      <!--<form method="post" class="contactForm">
                     
                     
                      <div class="row">
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                              <div class="validation"></div>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <!--<button type="submit" name="submit" class="button button-a button-big button-rouded">Send Message</button>
						  <input type="submit" name="submit" value="Submit">
                        </div>
                      </div>
                    </form>-->
					
					<?php echo $error; ?>
					<form action="" method="post">
          	 <div class="form-group">
			    
			    <input type="text" class="form-control" id="text" name="name" placeholder="Input your name" required="required">
			  </div>
			  
			  <div class="form-group">
			    
			 <input type="text" class="form-control" id="phone" name="phone" placeholder="Input your phone" minlength="10" 
			 maxlength="10"  required="required">
			  </div>
			  <div class="form-group">
			    
			    <input type="email" class="form-control" id="email" name="email" placeholder="Input your email" pattern="[^@]+@[^@]+\.[a-zA-Z]{2,6}" required="required">
			  </div>
			  <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                            <div class="validation"></div>
                          </div>
                        </div>
			  
			  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
			</form>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="title-box-2 pt-4 pt-md-0">
                    <h5 class="title-left">
                      Get in Touch
                    </h5>
                  </div>
                  <div class="more-info">
                    <p class="lead">
                      I am a web developer. I am a freelancer, blogger, content writer, article writer, ghost writer, review writer, guest writer.
					  My blog is https://www.socialinformation.site/
					  <br>
					  I provide services like - PPT presentation, backlinks, web page optimization, Website testing, FB page creation, Grow website traffic.
                    </p>
                    <ul class="list-ico">
                      <li><span class="ion-ios-location"></span> Begampur, Chanditala II, Hooghly, West Bengal, 712306</li>
                      <li><span class="ion-ios-telephone"></span> +91 8420566643</li>
                      <li><span class="ion-email"></span> shambhu.paul1200@gmail.com / shambhupaul383@gmail.com</li>
                    </ul>
                  </div>
                  <div class="socials">
                    <ul>
                      <li><a href="https://www.facebook.com/shambhunath.paul.125/"><span class="ico-circle"><i class="ion-social-facebook"></i></span></a></li>
                      <li><a href="https://www.instagram.com/shambhunathpaul1991/"><span class="ico-circle"><i class="ion-social-instagram"></i></span></a></li>
                      <li><a href="https://twitter.com/SHAMBHUPAUL6/"><span class="ico-circle"><i class="ion-social-twitter"></i></span></a></li>
                      <li><a href="https://www.pinterest.ca/shambhupaul1200/"><span class="ico-circle"><i class="ion-social-pinterest"></i></span></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="copyright-box">
              <p class="copyright">&copy; Copyright <strong>MyPortFolio</strong>. All Rights Reserved</p>
              <div class="credits">
                
                Designed by <a href="https://www.socialinformation.site/">Social Information</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </section>
  <!--/ Section Contact-footer End /-->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/popper/popper.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/counterup/jquery.waypoints.min.js"></script>
  <script src="lib/counterup/jquery.counterup.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/typed/typed.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
